package org.groupid;

public interface FightingPower {
    String getFightingPowerDesc();
}
