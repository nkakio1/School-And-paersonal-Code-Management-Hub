package org.groupid;

public interface BattleGround {
    String getBattleGroundDesc();
}